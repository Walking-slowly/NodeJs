//引用模块 gulp gulp-sass
let gulp = require('gulp');
let sass = require('gulp-sass');

//sass->css
gulp.task('compileSass',function(){
    //先查找sass文件所在目录
    gulp.src('./src/sass/*.scss')//返回文件流

    //scss->css
    .pipe(sass({outputStyle:'expanded'}))

    //输出到硬盘
    .pipe(gulp.dest('./src/css/'))
})

//监听sass
// gulp.task('jtSass',function(){
//     gulp.watch('./src/sass/*.scss',['compileSass'])
// })

//自动刷新
let browserSync = require('browser-sync');

gulp.task('server',()=>{
    browserSync({
        //服务器路径
        // server:'./src/',

        //代理服务器
        proxy:'http://localhost:888',
        

        //端口
        port:1001,

        //监听文件修改，自动刷新
        files:['./src/**/*.html','./src/css/*.css','./src/api/*.php']
    });

    // 监听sass文件修改，并自动编译
    gulp.watch('./src/sass/*.scss',['compileSass']);
})