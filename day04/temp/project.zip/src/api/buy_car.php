<?php
    require('connect.php');
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    $name = isset($_GET['name']) ? $_GET['name'] : null;
    $sale = isset($_GET['sale']) ? $_GET['sale'] : null;
    $qty = isset($_GET['qty']) ? $_GET['qty'] : null;
    $price = isset($_GET['price']) ? $_GET['price'] : null;
    $images = isset($_GET['images']) ? $_GET['images'] : null;

    $buy_id = "select * from buy_car where id='$id'";
    $buy_car_id = $conn->query($buy_id);

    //查找是否存在商品，有就只数量增加，没有就数据写入数据库
    if($buy_car_id->num_rows>0){
        $goods_qty = $buy_car_id->fetch_assoc();
        $num = $goods_qty['qty']*1;
        $goods_qty_res =  $num + $qty ;
        $conn->query("update buy_car set qty='$goods_qty_res' where id='$id'");
    }else{
        $conn->query("insert into buy_car (id,name,sale,qty,price,images) values ('$id','$name','$sale','$qty','$price','$images')");
    }

    //购物车数据返回前端
    $res = "select * from buy_car";

    $result = $conn->query($res);

    //结果集，得到数组
    $goods = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($goods,JSON_UNESCAPED_UNICODE);

    //删除商品
    $remove_id = isset($_GET['remove_id']) ? $_GET['remove_id'] : null;

    $conn->query("delete from buy_car where id='$remove_id'");
?>