<?php
    require('connect.php');

    //查询结果集
    $res1 = $conn->query("select * from goods where category='zhibo'");
    $res2 = $conn->query("select * from goods where category='xsqg_9'");
    $res3 = $conn->query("select * from goods where category='xsqg_15'");
    $res4 = $conn->query("select * from goods where category='xsqg_20'");
    $res5 = $conn->query("select * from goods where category='xptj'");
    $res6 = $conn->query("select * from goods where category='big'");
    $res7 = $conn->query("select * from goods where category='rx' order by id limit 0,7");
    $res8 = $conn->query("select * from goods where category='mbhl' order by id limit 0,7");
    $res9 = $conn->query("select * from goods where category='xscz'");
    $res10 = $conn->query("select * from goods where category='mfhf'");
    $res11 = $conn->query("select * from goods where category='sthl'");
    $res12 = $conn->query("select * from goods where category='mrgj'");
    $res13 = $conn->query("select * from goods where category='kqhl'");
    $res14 = $conn->query("select * from goods where category='spjk_big'");
    $res15 = $conn->query("select * from goods where category='ylct'");
    $res16 = $conn->query("select * from goods where category='sprx'");
    $res17 = $conn->query("select * from goods where category='yybj'");
    $res18 = $conn->query("select * from goods where category='lytw'");
    $res19 = $conn->query("select * from goods where category='xxsp'");
    $res20 = $conn->query("select * from goods where category='jsmc'");
    $res21 = $conn->query("select * from goods where category='sxsp'");
    $res22 = $conn->query("select * from goods where category='ccry_big'");
    $res23 = $conn->query("select * from goods where category='ccrx'");
    $res24 = $conn->query("select * from goods where category='prgj'");
    $res25 = $conn->query("select * from goods where category='cfdq'");
    $res26 = $conn->query("select * from goods where category='cfyj'");
    $res27 = $conn->query("select * from goods where category='cyyj'");
    $res28 = $conn->query("select * from goods where category='cfpj'");
    $res29 = $conn->query("select * from goods where category='shyp'");
    $res30 = $conn->query("select * from goods where category='jkbj'");
    $res31 = $conn->query("select * from goods where category='qjsn'");
    $res32 = $conn->query("select * from goods where category='jzjc'");
    $res33 = $conn->query("select * from goods where category='fzps_big'");
    $res34 = $conn->query("select * from goods where category='fzrx'");
    $res35 = $conn->query("select * from goods where category='nsfz'");
    $res36 = $conn->query("select * from goods where category='man_fz'");
    $res37 = $conn->query("select * from goods where category='ny'");
    $res38 = $conn->query("select * from goods where category='xx'");
    $res39 = $conn->query("select * from goods where category='xb'");
    $res40 = $conn->query("select * from goods where category='yjps'");
    $res41 = $conn->query("select * from goods where category='ydhw'");
    $res42 = $conn->query("select * from goods where category='zb'");
    $res43 = $conn->query("select * from goods where category='zbcp'");

    // 获取数据（使用查询结果集）
    $zhibo = $res1->fetch_all(MYSQLI_ASSOC);
    $xsqg_9 = $res2->fetch_all(MYSQLI_ASSOC);
    $xsqg_15 = $res3->fetch_all(MYSQLI_ASSOC);
    $xsqg_20 = $res4->fetch_all(MYSQLI_ASSOC);
    $xptj = $res5->fetch_all(MYSQLI_ASSOC);
    $big = $res6->fetch_all(MYSQLI_ASSOC);
    $rx = $res7->fetch_all(MYSQLI_ASSOC);
    $mbhl = $res8->fetch_all(MYSQLI_ASSOC);
    $xscz = $res9->fetch_all(MYSQLI_ASSOC);
    $mfhf = $res10->fetch_all(MYSQLI_ASSOC);
    $sthl = $res11->fetch_all(MYSQLI_ASSOC);
    $mrgj = $res12->fetch_all(MYSQLI_ASSOC);
    $kqhl = $res13->fetch_all(MYSQLI_ASSOC);
    $spjk_big = $res14->fetch_all(MYSQLI_ASSOC);
    $ylct = $res15->fetch_all(MYSQLI_ASSOC);
    $sprx = $res16->fetch_all(MYSQLI_ASSOC);
    $yybj = $res17->fetch_all(MYSQLI_ASSOC);
    $lytw = $res18->fetch_all(MYSQLI_ASSOC);
    $xxsp = $res19->fetch_all(MYSQLI_ASSOC);
    $jsmc = $res20->fetch_all(MYSQLI_ASSOC);
    $sxsp = $res21->fetch_all(MYSQLI_ASSOC);
    $ccry_big = $res22->fetch_all(MYSQLI_ASSOC);
    $ccrx = $res23->fetch_all(MYSQLI_ASSOC);
    $prgj = $res24->fetch_all(MYSQLI_ASSOC);
    $cfdq = $res25->fetch_all(MYSQLI_ASSOC);
    $cfyj = $res26->fetch_all(MYSQLI_ASSOC);
    $cyyj = $res27->fetch_all(MYSQLI_ASSOC);
    $cfpj = $res28->fetch_all(MYSQLI_ASSOC);
    $shyp = $res29->fetch_all(MYSQLI_ASSOC);
    $jkbj = $res30->fetch_all(MYSQLI_ASSOC);
    $qjsn = $res31->fetch_all(MYSQLI_ASSOC);
    $jzjc = $res32->fetch_all(MYSQLI_ASSOC);
    $fzps_big = $res33->fetch_all(MYSQLI_ASSOC);
    $fzrx = $res34->fetch_all(MYSQLI_ASSOC);
    $nsfz = $res35->fetch_all(MYSQLI_ASSOC);
    $man_fz = $res36->fetch_all(MYSQLI_ASSOC);
    $ny = $res37->fetch_all(MYSQLI_ASSOC);
    $xx = $res38->fetch_all(MYSQLI_ASSOC);
    $xb = $res39->fetch_all(MYSQLI_ASSOC);
    $yjps = $res40->fetch_all(MYSQLI_ASSOC);
    $ydhw = $res41->fetch_all(MYSQLI_ASSOC);
    $zb = $res42->fetch_all(MYSQLI_ASSOC);
    $zbcp = $res43->fetch_all(MYSQLI_ASSOC);


    //创建数组
    $res = array(
            'zhibo'=>$zhibo,
            'xsqg_9'=>$xsqg_9,
            'xsqg_15'=>$xsqg_15,
            'xsqg_20'=>$xsqg_20,
            'xptj'=>$xptj,
            'big'=>$big,
            'rx'=>$rx,
            'mbhl'=>$mbhl,
            'xscz'=>$xscz,
            'mfhf'=>$mfhf,
            'sthl'=>$sthl,
            'mrgj'=>$mrgj,
            'kqhl'=>$kqhl,
            'spjk_big'=>$spjk_big,
            'ylct'=>$ylct,
            'sprx'=>$sprx,
            'yybj'=>$yybj,
            'lytw'=>$lytw,
            'xxsp'=>$xxsp,
            'jsmc'=>$jsmc,
            'sxsp'=>$sxsp,
            'ccry_big'=>$ccry_big,
            'ccrx'=>$ccrx,
            'prgj'=>$prgj,
            'cfdq'=>$cfdq,
            'cfyj'=>$cfyj,
            'cyyj'=>$cyyj,
            'cfpj'=>$cfpj,
            'shyp'=>$shyp,
            'jkbj'=>$jkbj,
            'qjsn'=>$qjsn,
            'jzjc'=>$jzjc,
            'fzps_big'=>$fzps_big,
            'fzrx'=>$fzrx,
            'nsfz'=>$nsfz,
            'man_fz'=>$man_fz,
            'ny'=>$ny,
            'xx'=>$xx,
            'xb'=>$xb,
            'yjps'=>$yjps,
            'ydhw'=>$ydhw,
            'zb'=>$zb,
            'zbcp'=>$zbcp,
        );


    // 关闭数据库，避免资源浪费
    $conn->close();

    // var_dump($res);

    echo json_encode($res,JSON_UNESCAPED_UNICODE);

?>