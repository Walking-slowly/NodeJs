<?php
    require('connect.php');

    $id = isset($_GET['id']) ? $_GET['id'] : null;

    $res = "select * from goods where id='$id'";

    $result = $conn->query($res);

    //结果集，得到数组
    $goods = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($goods,JSON_UNESCAPED_UNICODE);

?>