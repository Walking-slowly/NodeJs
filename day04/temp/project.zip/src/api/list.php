<?php
    require('connect.php');
    $res1 = $conn->query("select * from goods where category='ghmz'");
    $res2 = $conn->query("select * from goods where category='spjk'");
    $res3 = $conn->query("select * from goods where category='ccry'");
    $res4 = $conn->query("select * from goods where category='fzps'");
    $res5 = $conn->query("select * from goods where category='byjf'");
    $res6 = $conn->query("select * from goods where category='jdsm'");
    $res7 = $conn->query("select * from goods where category='mykh'");

    //结果集，得到数组
    $ghmz = $res1->fetch_all(MYSQLI_ASSOC);
    $spjk = $res2->fetch_all(MYSQLI_ASSOC);
    $ccry = $res3->fetch_all(MYSQLI_ASSOC);
    $fzps = $res4->fetch_all(MYSQLI_ASSOC);
    $byjf = $res5->fetch_all(MYSQLI_ASSOC);
    $jdsm = $res6->fetch_all(MYSQLI_ASSOC);
    $mykh = $res7->fetch_all(MYSQLI_ASSOC);

    $arr = array(
            'ghmz'=>$ghmz,
            'spjk'=>$spjk,
            'ccry'=>$ccry,
            'fzps'=>$fzps,
            'byjf'=>$byjf,
            'jdsm'=>$jdsm,
            'mykh'=>$mykh,
        );
    // var_dump($arr);
    echo json_encode($arr,JSON_UNESCAPED_UNICODE);
?>