<?php
    require('connect.php');

    $username = isset($_GET['username']) ? $_GET['username'] : null;
    $password1 = isset($_GET['password1']) ? $_GET['password1'] : null;
    $type = isset($_GET['type']) ? $_GET['type'] : null;

    $sql = "select username from userlist where username='$username'";

    $result = $conn->query($sql);

    if($result->num_rows>0){
        echo 'success';
        if($type =='denglu'){
            $sql = "select username from userlist where password1='$password1'";
            $result = $conn->query($sql);
            if($result->num_rows>0){
                echo 'success';
            }else{
                echo 'fail';
            }
        }
    }else{
        echo 'fail';
    }

?>