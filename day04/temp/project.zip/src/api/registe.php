<?php
    require('connect.php');

    $username = isset($_GET['username']) ? $_GET['username'] : null;
    $password1 = isset($_GET['password1']) ? $_GET['password1'] : null;
    $type = isset($_GET['type']) ? $_GET['type'] : null;
    
    $sql = "select username from userlist where username='$username'";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        echo 'fail';
    }else{
        if($type =='zhuce'){
            $sql = "insert into userlist(username,password1) value('$username','$password1')";
            $result = $conn->query($sql);
            if($result){
                echo 'success';
            }else{
                echo 'fail';
            }
        }else{
            echo 'success';
        }
    }
?>