//配置参数
require.config({
    //配置别名（虚拟路径）
    paths:{
        //格式：别名--真实路径（基于baseUrl）
        jquery:'../lib/jquery-3.2.1'
    },

    //配置依赖
    shim:{
        
    }
})

require(['jquery'],function($){
    //脚部页面内容引入
    ;(function($){
        $('#footer').load('../html/footer.html');
    })(jQuery);

    //头部js
    ;(function($){
        $('.reg_tips_i').on('click',function(){
            $('.reg_tips').css('display','none');
        })
    })(jQuery)

    //购物车加载商品
    ;(function($){
        $.ajax({
            url:'../api/buy_car.php',
            dataType:'json',
            success:function(data){
                let res = data.map(function(item){
                    return `
                        <li class="goods_list clearfix" data-id="${item.id}">
                            <div class="p25 goods_checkbox">
                                <input type="checkbox" class="checkbox"/>
                            </div>
                            <div class="p25 goods_name">
                                <div class="goods_name_img">
                                    <img src="${item.images}" alt="${item.images}" />
                                </div>
                                <div class="goods_name_msg">
                                    ${item.name}
                                </div>
                            </div>
                            <div class="p25 goods_price">
                                <del>${item.price}</del>
                                <p class="goods_price_p">${item.sale}</p>
                            </div>
                            <div class="p25 goods_qty clearfix">
                                <i class="goods_decrease">-</i>
                                <input type="number" value="${item.qty}" class="goods_qyt_input"/>
                                <i class="goods_add">+</i>
                            </div>
                            <div class="p25 goods_sum">
                                <strong>
                                    ￥
                                    <em class="goods_sum_em">${item.qty*item.sale}</em>
                                </strong>
                            </div>
                            <div class="p25 goods_del">
                                <span class="del">删除</span>
                            </div>
                        </li>
                    `
                });
                $('.goods_ul').html(res);

                //页面默认全部勾选
                $('#main').find(':checkbox').prop('checked',true);

                //已选商品数量
                $('.checkbox_num').text($('.goods_ul').find(':checked').length);

                //结算总费用
                totle();
            }
        })
    })(jQuery);

    //购物车数量增减以及计算对应商品的价格
    ;(function($){
        $('.goods_ul').on('click','i',function(){
            if($(this).text() === '-'){
                $(this).next('input').val($(this).next('input').val()*1-1);
                if($(this).next('input').val() <= 0){
                    $(this).next('input').val(1)
                }
                let price = $(this).parent('.goods_qty').prev('.goods_price').children('.goods_price_p').text();console.log(price)
                let price_sum = price * $(this).next('.goods_qyt_input').val();
                $(this).parent('.goods_qty').next('.goods_sum').children('strong').children('.goods_sum_em').text(price_sum);
            }
            if($(this).text() === '+'){
                $(this).prev('input').val($(this).prev('input').val()*1+1);
                if($(this).prev('input').val() >= 9999){
                    $(this).prev('input').val(9999)
                }
                let price = $(this).parent('.goods_qty').prev('.goods_price').children('.goods_price_p').text();
                let price_sum = price * $(this).prev('.goods_qyt_input').val();
                $(this).parent('.goods_qty').next('.goods_sum').children('strong').children('.goods_sum_em').text(price_sum);
            }

            //结算总费用
            totle();
        })
        $('.goods_ul').on('blur','.goods_qyt_input',function(){
            if($(this).val() >= 9999){
                $(this).val(9999)
            }
            if($(this).val() <= 0){
                $(this).val(1)
            }
            let price = $(this).parent('.goods_qty').prev('.goods_price').children('.goods_price_p').text();
            let price_sum = price * $(this).val();
            $(this).parent('.goods_qty').next('.goods_sum').children('strong').children('.goods_sum_em').text(price_sum);

            //结算总费用
            totle();
        })
    })(jQuery);

    //删除商品
    ;(function($){
        $('.goods_ul').on('click','.del',function(){
            let id = $(this).closest('.goods_list').attr('data-id');
            $(this).closest('.goods_list').remove();
            $.ajax({
                url:'../api/buy_car.php',
                data:{
                    remove_id:id
                }
            });
            //已选商品数量
            $('.checkbox_num').text($('.goods_ul').find(':checked').length);

            //结算总费用
            totle();
        })
    })(jQuery);

    //勾选需要付款的商品进行计算价格
    ;(function($){
        //勾选单个商品
        $('.goods_ul').on('click','.checkbox',function(){
            if(this.checked){
                $(this).closest('.goods_list').css('background','#fffbf0');
            }else{
                $(this).closest('.goods_list').css('background','#fff');
            }

            //全选按钮状态
            let $checked_all = $('.goods_ul').find(':checked');//获取被选择的商品
            let $checkbox_all = $('.goods_ul').find(':checkbox');//获取购物车的商品
            $($('.goods_all')[0]).prop('checked',$checked_all.length === $checkbox_all.length);
            $($('.goods_all')[1]).prop('checked',$checked_all.length === $checkbox_all.length);

            //已选商品数量
            $('.checkbox_num').text($('.goods_ul').find(':checked').length);

            //结算总费用
            totle();
        })

        //勾选全部商品
        $('#main').on('click','.goods_all',function(){
            $('#main').find(':checkbox').prop('checked',this.checked);

            //已选商品数量
            $('.checkbox_num').text($('.goods_ul').find(':checked').length);

            //结算总费用
            totle();
        })

    })(jQuery)

    //封装计算总价
    function totle(){
        let totle_price = $('.goods_ul').children('.goods_list');
        let totle = 0 ;
        for(let i=0;i<totle_price.length;i++){
            if($(totle_price[i]).find('.checkbox').prop('checked') == true){
                totle+= $(totle_price[i]).find('.goods_sum_em').text()*1;
            }
        } 
        $('.cartTotal').text(totle);
    }
})
