//获取网页的数据，懒人专用
let lsm_goods = [];
$('.sl_list_ul').children('li').each(function(a,item){
    let idx = [$(item).find('.sl_goods_img').children('img').attr('original')][0].lastIndexOf('/');
    lsm_goods.push({
        images:'../images/goods'+$(item).find('.sl_goods_img').children('img').attr('original').substring(idx),
        name:$(item).find('.sl_goods_img').children('img').attr('alt'),
        price:$(item).find('.sl_price').find('del').text().replace(/[^0-9\.]/ig,''),
        sale:$(item).find('.sl_price').find('span').text().replace(/[^0-9\.]/ig,''),
        category:'mykh'
    })
    
})
console.log(JSON.stringify(lsm_goods))