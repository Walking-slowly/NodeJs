//配置参数
require.config({
    //配置别名（虚拟路径）
    paths:{
        //格式：别名--真实路径（基于baseUrl）
        jquery:'../lib/jquery-3.2.1',
        header:'header',
        right_slider:'right_slider',
        xzoom:'../lib/jquery-xZoom/jquery.xZoom',
    },

    //配置依赖
    shim:{
        header:['jquery'],
        right_slider:['jquery'],
        xzoom:['jquery'],
    }
})

require(['jquery','header','right_slider','xzoom'],function($){
    //头部脚步页面引入
    ;(function($){
        $('#footer').load('../html/footer.html');
    })(jQuery);

    //根据ID拿到商品数据
    ;(function($){
        let id = location.search.slice(4);
        $.ajax({
            url:'../api/goodslis.php',
            dataType:'json',
            data:{
                id:id
            },
            success:function(data){
                data.forEach(function(item){
                    $('.big_img').children('img').attr('src',item.images);
                    $('.big_img').children('img').attr('data-big',item.images);
                    $('.small_img').children('li').children('img').attr('src',item.images);
                    $('.l_title').text(item.name.replace(/�\?/ig,''));
                    $('.h2_title').text(item.name.replace(/�\?/ig,''));
                    $('.h3_title').text(item.intro);
                    $('.price').children('strong').text(item.sale);
                    $('.price').children('del').text(item.price);
                    $('.bianhao_id').text('编号：'+item.id);
                })

                //点击添加购物车
                $('.byu_car_btn').on('click',function(){
                    let qty = $('#goods_qty_num').val();
                    $.ajax({
                        url:'../api/buy_car.php',
                        dataType:'json',
                        data:{
                            id:id*1,
                            name:$('.h2_title').text(),
                            images:$('.big_img').children('img').attr('src'),
                            sale:$('.price').children('strong').text(),
                            price:$('.price').children('del').text(),
                            qty:qty
                        },
                        success:function(data){
                            //右侧购物车图标数量+1
                            $('.car_num').text(data.length);
                        }
                    });

                    //购物车飞入效果
                    let src = $('.big_img').children('img').attr('src');
                    let buy_x = $('.buycar').children('i').offset().left;
                    let buy_y = $('.buycar').children('i').offset().top;
                    let $img = $('<img/>').attr('src',src).addClass('change').css({
                        'display':'block',
                        'width':'30px',
                        'height':'30px',
                        'border-radius':'50%',
                        'position':'absolute',
                        'top':'95%',
                        'right':'35%'
                    })
                    $('body').append($img);
                    $img.animate({
                        left:buy_x,
                        top:buy_y
                    },'slow',function(){
                        $('body').children('.change').remove();
                    });
                });
                //右侧购物车图标数量+1
                $.ajax({
                    url:'../api/buy_car.php',
                    dataType:'json',
                    success:function(data){
                        
                        $('.car_num').text(data.length);
                    }
                })

                //点击立即购买添加购物车
                $('.buy_btn').on('click',function(){
                    let qty = $('#goods_qty_num').val();
                    $.ajax({
                        url:'../api/buy_car.php',
                        data:{
                            id:id,
                            name:$('.h2_title').text(),
                            images:$('.big_img').children('img').attr('src'),
                            sale:$('.price').children('strong').text(),
                            price:$('.price').children('del').text(),
                            qty:qty
                        }
                    });

                })


                //放大镜
                ;(function($){
                    $('.big_img').xZoom({
                        width:382,
                        height:382,
                        position:'right',
                    })
                })(jQuery);
            }
        })
    })(jQuery);


    //商品qty增减
    ;(function($){
        $('.goods_qty_decrease').on('click',function(){
            $('#goods_qty_num').val($('#goods_qty_num').val()*1-1);
            if($('#goods_qty_num').val() <= 0){
                $('#goods_qty_num').val(1)
            }
        })
        $('.goods_qty_add').on('click',function(){
            $('#goods_qty_num').val($('#goods_qty_num').val()*1+1);
            if($('#goods_qty_num').val() >= 9999){
                $('#goods_qty_num').val(9999)
            }
        })
        $('#goods_qty_num').on('blur',function(){
            if($('#goods_qty_num').val() >= 9999){
                $('#goods_qty_num').val(9999)
            }
        })
    })(jQuery);

})