;(function($){
    $('#header').load('../html/header.html',function(){
        $('.reg_tips_i').on('click',function(){
            $('.reg_tips').css('display','none');
        })
    });
})(jQuery);