//配置参数
require.config({
    //配置别名（虚拟路径）
    paths:{
        //格式：别名--真实路径（基于baseUrl）
        jquery:'../lib/jquery-3.2.1',
        xcarousel:'../lib/jquery-xcarousel/jquery.xCarousel',
        header:'../js/header',
        right_slider:'../js/right_slider',
    },

    //配置依赖
    shim:{
        xcarousel:['jquery'],
        header:['jquery'],
        right_slider:['jquery'],
    }
})

require(['jquery','xcarousel','right_slider','header'],function($){
    //这里的代码：[]中的模块加载完成后执行
    //但是，不保证[]中模块的加载顺序
    
    jQuery(function($){
        //脚部写入主页
        $('#footer').load('../html/footer.html');
        
        //轮播图
        $('.banner').xCarousel({
            width:'100%',
            height:380,
            imgs:[
            '../images/web-101-101-1-1522632545.jpg',
            '../images/web-101-101-2-1523154142.jpg',
            '../images/web-101-101-3-1523154181.jpg',
            '../images/web-101-101-4-1521690983.jpg'
            ],
            type:'fade',
            duration:3000,
        })

    /*
        -----------内容部分的js--------------------------------------------------------------------
     */
    
        //nav--------------------------
         ;(function($){
             $('.index_type_ul').on('mouseenter','li',function(){
                $(this).addClass('fff').children('.type_list').css('display','block');
                $(this).siblings().children('.type_list').css('display','none');
             }).on('mouseleave','li',function(){
                $(this).removeClass('fff').children('.type_list').css('display','none');
             });
            
         })(jQuery)


         //数据写入主页---------------------------
         ;(function($){
            $.ajax({
                url:'../api/goods.php',
                dataType:'json',
                success:function(data){
                    //今日直播的内容写入--------------------------------------
                    let $zhibo_content = $('.zhibo_content');
                    let zhibo = data.zhibo.map(function(item){
                        return creatData1(item);
                    })
                    $zhibo_content.html(zhibo);
                    $zhibo_content.width($zhibo_content.children('li').first().outerWidth()*$zhibo_content.children('li').length);

                    //限时抢购的内容写入----------------------------------------
                    //(1)
                    let $zhuanchang1 = $('.zhuanchang1');
                    let xsqg_9 = data.xsqg_9.map(function(item){
                        return creatData2(item);
                    })
                    $zhuanchang1.html(xsqg_9);
                    $zhuanchang1.width($zhuanchang1.children('li').first().outerWidth()*$zhuanchang1.children('li').length);
                    //(2)
                    let $zhuanchang2 = $('.zhuanchang2');
                    let xsqg_15 = data.xsqg_15.map(function(item){
                        return creatData2(item);
                    })
                    $zhuanchang2.html(xsqg_15);
                    $zhuanchang2.width($zhuanchang2.children('li').first().outerWidth()*$zhuanchang2.children('li').length);
                    //(3)
                    let $zhuanchang3 = $('.zhuanchang3');
                    let xsqg_20 = data.xsqg_20.map(function(item){
                        return creatData2(item);
                    })
                    $zhuanchang3.html(xsqg_20);
                    $zhuanchang3.width($zhuanchang3.children('li').first().outerWidth()*$zhuanchang3.children('li').length);

                    //新品推荐的内容写入------------------------------------------------
                    let $xptj_data = $('.xptj_data');
                    let xptj = data.xptj.map(function(item){
                        return creatData1(item)
                    })
                    $xptj_data.html(xptj);

                    //新品推荐的内容写入---------------------------------------------
                    
                    //热销
                    let $rx = $('.rx');
                    let rx = data.rx.map(function(item){
                        return creatData1(item);
                    })
                    $rx.html(rx);

                    //面部护理
                    let $mbhl = $('.mbhl');
                    let mbhl = data.mbhl.map(function(item){
                        return creatData1(item);
                    })
                    $mbhl.html(mbhl);

                    //香水彩妆
                    let $xscz = $('.xscz');
                    let xscz = data.xscz.map(function(item){
                        return creatData1(item);
                    })
                    $xscz.html(xscz);

                    //美发护发
                    let $mfhf = $('.mfhf');
                    let mfhf = data.mfhf.map(function(item){
                        return creatData1(item);
                    })
                    $mfhf.html(mfhf);

                    //身体护理
                    let $sthl = $('.sthl');
                    let sthl = data.sthl.map(function(item){
                        return creatData1(item);
                    })
                    $sthl.html(sthl);

                    //美容工具
                    let $mrgj = $('.mrgj');
                    let mrgj = data.mrgj.map(function(item){
                        return creatData1(item);
                    })
                    $mrgj.html(mrgj);

                    //口腔护理
                    let $kqhl = $('.kqhl');
                    let kqhl = data.kqhl.map(function(item){
                        return creatData1(item);
                    })
                    $kqhl.html(kqhl);

                    //大图写入
                    let $ghmz_data = $('.ghmz_data').children('ul');
                    for(let i=0;i<$ghmz_data.length;i++){
                        let $imgSrc = data.big[0].images;
                        let $li = $('<li/>').addClass('big');
                        let $img = $('<img/>').attr('src',$imgSrc);
                        $li.append($img);
                        $($ghmz_data[i]).prepend($li);
                    }

                    //食品健康的内容写入---------------------------------------------
                    
                    //食品热销
                    let $sprx = $('.sprx');
                    let sprx = data.sprx.map(function(item){
                        return creatData1(item);
                    })
                    $sprx.html(sprx);

                    //饮料冲调
                    let $ylct = $('.ylct');
                    let ylct = data.ylct.map(function(item){
                        return creatData1(item);
                    })
                    $ylct.html(ylct);

                    //营养保健
                    let $yybj = $('.yybj');
                    let yybj = data.yybj.map(function(item){
                        return creatData1(item);
                    })
                    $yybj.html(yybj);

                    //粮油调味
                    let $lytw = $('.lytw');
                    let lytw = data.lytw.map(function(item){
                        return creatData1(item);
                    })
                    $lytw.html(lytw);

                    //休闲食品
                    let $xxsp = $('.xxsp');
                    let xxsp = data.xxsp.map(function(item){
                        return creatData1(item);
                    })
                    $xxsp.html(xxsp);

                    //酒水茗茶
                    let $jsmc = $('.jsmc');
                    let jsmc = data.jsmc.map(function(item){
                        return creatData1(item);
                    })
                    $jsmc.html(jsmc);

                    //生鲜食品
                    let $sxsp = $('.sxsp');
                    let sxsp = data.sxsp.map(function(item){
                        return creatData1(item);
                    })
                    $sxsp.html(sxsp);

                    //大图写入
                    let $spjk_data = $('.spjk_data').children('ul');
                    for(let i=0;i<$spjk_data.length;i++){
                        let $imgSrc = data.big[0].images;
                        let $li = $('<li/>').addClass('big');
                        let $img = $('<img/>').attr('src',$imgSrc);
                        $li.append($img);
                        $($spjk_data[i]).prepend($li);
                    }

                    //食品健康的内容写入---------------------------------------------
                    
                    //餐具热销
                    let $ccrx = $('.ccrx');
                    let ccrx = data.ccrx.map(function(item){
                        return creatData1(item);
                    })
                    $ccrx.html(ccrx);

                    //烹饪锅具
                    let $prgj = $('.prgj');
                    let prgj = data.prgj.map(function(item){
                        return creatData1(item);
                    })
                    $prgj.html(prgj);

                    //厨房电器
                    let $cfdq = $('.cfdq');
                    let cfdq = data.cfdq.map(function(item){
                        return creatData1(item);
                    })
                    $cfdq.html(cfdq);

                    //厨房用具
                    let $cfyj = $('.cfyj');
                    let cfyj = data.cfyj.map(function(item){
                        return creatData1(item);
                    })
                    $cfyj.html(cfyj);

                    //餐饮用具
                    let $cyyj = $('.cyyj');
                    let cyyj = data.cyyj.map(function(item){
                        return creatData1(item);
                    })
                    $cyyj.html(cyyj);

                    //厨房配件
                    let $cfpj = $('.cfpj');
                    let cfpj = data.cfpj.map(function(item){
                        return creatData1(item);
                    })
                    $cfpj.html(cfpj);

                    //生活用品
                    let $shyp = $('.shyp');
                    let shyp = data.shyp.map(function(item){
                        return creatData1(item);
                    })
                    $shyp.html(shyp);

                    //健康保健
                    let $jkbj = $('.jkbj');
                    let jkbj = data.jkbj.map(function(item){
                        return creatData1(item);
                    })
                    $jkbj.html(jkbj);

                    //清洁收纳
                    let $qjsn = $('.qjsn');
                    let qjsn = data.qjsn.map(function(item){
                        return creatData1(item);
                    })
                    $qjsn.html(qjsn);

                    //家装建材
                    let $jzjc = $('.jzjc');
                    let jzjc = data.jzjc.map(function(item){
                        return creatData1(item);
                    })
                    $jzjc.html(jzjc);

                    //大图写入
                    let $ccry_data = $('.ccry_data').children('ul');
                    for(let i=0;i<$ccry_data.length;i++){
                        let $imgSrc = data.big[0].images;
                        let $li = $('<li/>').addClass('big');
                        let $img = $('<img/>').attr('src',$imgSrc);
                        $li.append($img);
                        $($ccry_data[i]).prepend($li);
                    }

                    //服装配饰的内容写入---------------------------------------------
                    
                    //服装热销
                    let $fzrx = $('.fzrx');
                    let fzrx = data.fzrx.map(function(item){
                        return creatData1(item);
                    })
                    $fzrx.html(fzrx);

                    //女士服装
                    let $nsfz = $('.nsfz');
                    let nsfz = data.nsfz.map(function(item){
                        return creatData1(item);
                    })
                    $nsfz.html(nsfz);

                    //男士服装
                    let $man_fz = $('.man_fz');
                    let man_fz = data.man_fz.map(function(item){
                        return creatData1(item);
                    })
                    $man_fz.html(man_fz);

                    //内衣
                    let $ny = $('.ny');
                    let ny = data.ny.map(function(item){
                        return creatData1(item);
                    })
                    $ny.html(ny);

                    //鞋靴
                    let $xx = $('.xx');
                    let xx = data.xx.map(function(item){
                        return creatData1(item);
                    })
                    $xx.html(xx);

                    //箱包
                    let $xb = $('.xb');
                    let xb = data.xb.map(function(item){
                        return creatData1(item);
                    })
                    $xb.html(xb);

                    //眼镜配饰
                    let $yjps = $('.yjps');
                    let yjps = data.yjps.map(function(item){
                        return creatData1(item);
                    })
                    $yjps.html(yjps);

                    //运动/户外
                    let $ydhw = $('.ydhw');
                    let ydhw = data.ydhw.map(function(item){
                        return creatData1(item);
                    })
                    $ydhw.html(ydhw);

                    //钟表
                    let $zb = $('.zb');
                    let zb = data.zb.map(function(item){
                        return creatData1(item);
                    })
                    $zb.html(zb);

                    //珠宝藏品
                    let $zbcp = $('.zbcp');
                    let zbcp = data.zbcp.map(function(item){
                        return creatData1(item);
                    })
                    $zbcp.html(zbcp);

                    //大图写入
                    let $fzps_data = $('.fzps_data').children('ul');
                    for(let i=0;i<$fzps_data.length;i++){
                        let $imgSrc = data.big[0].images;
                        let $li = $('<li/>').addClass('big');
                        let $img = $('<img/>').attr('src',$imgSrc);
                        $li.append($img);
                        $($fzps_data[i]).prepend($li);
                    }
                }
            })
            
            $.ajax({
                url:'../api/buy_car.php',
                dataType:'json',
                success:function(data){
                    //右侧购物车图标数量+1
                    $('.car_num').text(data.length);
                }
            });
         })(jQuery)
        
        //直播的js------------------------------
        //箭头显示
        ;(function($){
            $('.zhibo').on('mouseover',function(){
                $('.zhibo').children('.gundong').css('display','block');
            })
            $('.zhibo').on('mouseout',function(){
                $('.zhibo').children('.gundong').css('display','none');
            })

            //直播区左滚动
            $('.zhibo').children('.gundong').children('.a_prev').on('click',function(){
                let $liWidth = $('.zhibo_content').children('li').first().outerWidth();
                let $ulLeft = $('.zhibo_content').position().left;
                $('.zhibo_content').animate({
                    'left':-$liWidth+$ulLeft
                });
            })
            //直播区右滚动
            $('.zhibo').children('.gundong').children('.a_next').on('click',function(){
                let $liWidth = $('.zhibo_content').children('li').first().outerWidth();
                let $ulRight = $('.zhibo_content').position().left;
                $('.zhibo_content').animate({
                    'left':$liWidth+$ulRight
                });
            })
        })(jQuery);

        //限时抢购的js------------------------------
        ;(function($){
            let $xsqg = $('.xsqg').children('.title_1');
            let $li = $xsqg.children('.title_ul').children('li');
            let $zhuanchang = $('.zhuanchang').children('ul');
            for(let i=0;i<$li.length;i++){
                $xsqg.children('.title_ul').on('mouseover','li',function(){
                    let idx;
                    for(let i=0;i<$zhuanchang.length;i++){
                        if($li[i] === this){
                            idx = i;
                        }
                        $li[i].className = '';
                        $zhuanchang[i].style.display = 'none';
                    }
                    $(this).addClass('bottom_fff');
                    $zhuanchang[idx].style.display = 'block';
                })
            }

            $('.xsqg').on('mouseover',function(){
                $('.xsqg').children('.gundong').css('display','block');
            })
            $('.xsqg').on('mouseout',function(){
                $('.xsqg').children('.gundong').css('display','none');
            })
            //限时抢购左滚动
            $('.xsqg').children('.gundong').children('.a_prev').on('click',function(){
                let $ul = $('.zhuanchang').children('ul')
                $ul.each(function(idx,ele){
                    if(ele.style.display === 'block'){
                        let $ulLeft = $(this).position().left;
                        $(this).animate({
                            'left':$ulLeft-202
                        });
                    }
                })
            });
            //限时抢购右滚动
            $('.xsqg').children('.gundong').children('.a_next').on('click',function(){
                let $ul = $('.zhuanchang').children('ul')
                $ul.each(function(idx,ele){
                    if(ele.style.display === 'block'){
                        let $ulLeft = $(this).position().left;
                        $(this).animate({
                            'left':$ulLeft+202
                        });
                    }
                })
            });

        })(jQuery);

        //个护美妆的js------------------------------
        ;(function($){
            let $ghmz = $('.ghmz').children('.title_1');
            let $li = $ghmz.children('.title_ul').children('li');
            let $ghmz_data = $('.ghmz_data').children('ul');
            for(let i=0;i<$li.length;i++){
                $ghmz.children('.title_ul').on('mouseover','li',function(){
                    let idx;
                    for(let i=0;i<$ghmz_data.length;i++){
                        if($li[i] === this){
                            idx = i;
                        }
                        $li[i].className = '';
                        $ghmz_data[i].style.display = 'none';
                    }
                    $(this).addClass('bottom_fff');
                    $ghmz_data[idx].style.display = 'block';
                })
            }
        })(jQuery)

        //食品健康的js------------------------------
        ;(function($){
            let $spjk = $('.spjk').children('.title_1');
            let $li = $spjk.children('.title_ul').children('li');
            let $spjk_data = $('.spjk_data').children('ul');
            for(let i=0;i<$li.length;i++){
                $spjk.children('.title_ul').on('mouseover','li',function(){
                    let idx;
                    for(let i=0;i<$spjk_data.length;i++){
                        if($li[i] === this){
                            idx = i;
                        }
                        $li[i].className = '';
                        $spjk_data[i].style.display = 'none';
                    }
                    $(this).addClass('bottom_fff');
                    $spjk_data[idx].style.display = 'block';
                })
            }
        })(jQuery)

        //餐厨日用的js------------------------------
        ;(function($){
            let $ccry = $('.ccry').children('.title_1');
            let $li = $ccry.children('.title_ul').children('li');
            let $ccry_data = $('.ccry_data').children('ul');
            for(let i=0;i<$li.length;i++){
                $ccry.children('.title_ul').on('mouseover','li',function(){
                    let idx;
                    for(let i=0;i<$ccry_data.length;i++){
                        if($li[i] === this){
                            idx = i;
                        }
                        $li[i].className = '';
                        $ccry_data[i].style.display = 'none';
                    }
                    $(this).addClass('bottom_fff');
                    $ccry_data[idx].style.display = 'block';
                })
            }
        })(jQuery)

        //餐厨日用的js------------------------------
        ;(function($){
            let $fzps = $('.fzps').children('.title_1');
            let $li = $fzps.children('.title_ul').children('li');
            let $fzps_data = $('.fzps_data').children('ul');
            for(let i=0;i<$li.length;i++){
                $fzps.children('.title_ul').on('mouseover','li',function(){
                    let idx;
                    for(let i=0;i<$fzps_data.length;i++){
                        if($li[i] === this){
                            idx = i;
                        }
                        $li[i].className = '';
                        $fzps_data[i].style.display = 'none';
                    }
                    $(this).addClass('bottom_fff');
                    $fzps_data[idx].style.display = 'block';
                })
            }
        })(jQuery)
        

        //吸顶搜索----------------------------------
        ;(function($){
            $(window).on('scroll',function(){
                if($(window).scrollTop() >= 520){

                    $('.search_fixed').css('display','block').animate({
                        'height':'52px',
                    });
                    
                }else{
                    $('.search_fixed').css('display','none');
                }
            })
        })(jQuery)



        //每个商品绑定传参页面
        ;(function($){
            $('body').on('click','.goodslis',function(){
                let id = $(this).attr('data-id');
                location.href = '../html/goodslis.html?id='+id;
            })
        })(jQuery);

        //列表页跳转
        ;(function($){
            $('.type_list').on('click','li',function(){
                let fenlei = $(this).closest('.fenlei').children('a').text();
                let pinpai = $(this).find('a').text().slice(0,-1);
                let class_name = $(this).closest('.fenlei').attr('class').slice(7,12);
                location.href = '../html/list.html?fenlei='+fenlei+'&pinpai='+pinpai+'&class_name='+class_name;
            });
        })(jQuery);




        //封装写入数据的ul
        function creatData1(item){
            return `<li data-id="${item.id}" class="goodslis">
                <img src="${item.images}">
                <p class="p_name">${item.name}</p>
                <a href="#">${item.intro}</a>
                <div class="jiage">
                    <span>￥${item.sale}</span>
                    <del>${item.price}</del>
                </div>
            </li>`
        }
        function creatData2(item){
            return `<li data-id="${item.id}" class="goodslis">
                <img src="${item.images}">
                <div class="xsqg_djs">
                    <i class="i_xsqg_time"></i>
                    <span class="xsqg_djs_time">距结束</span>
                </div>
                <div class="name">
                    <p class="p_name">${item.name}</p>
                    <a href="#" class="intro">${item.intro}</a>
                </div>
                <div class="jiage clearfix">
                    <strong>￥${item.sale}</strong>
                    <del>${item.price}</del>
                    <a href="#" class="xsqg_buy">立即抢购</a>
                </div>
            </li>`
        }
    })
})