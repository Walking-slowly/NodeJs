//配置参数
require.config({
    //配置别名（虚拟路径）
    paths:{
        //格式：别名--真实路径（基于baseUrl）
        jquery:'../lib/jquery-3.2.1',
        header:'header'
    },

    //配置依赖
    shim:{
        header:['jquery'],
        right_slider:['jquery'],
    }
})
require(['jquery','header','right_slider'],function($){
    //脚部页面内容引入
    ;(function($){
        $('#footer').load('../html/footer.html');
    })(jQuery);

    //请求数据写入页面
    ;(function($){
        let loc = decodeURI(location.search).slice(1).split('&');
        let obj = {};
        loc.forEach(function(item){
            let arr = item.split('=');
            obj[arr[0]] = arr[1];
        });

        //分类写入
        $('.fenlei').html(obj.fenlei);

        //分类写入
        $('.pinpai').html(obj.pinpai);

        $.ajax({
            url:'../api/list.php',
            data:{
                class_name:obj.class_name
            },
            dataType:'json',
            success:function(data){
                data[obj.class_name].sort(function(a,b){
                    return b.id - a.id
                });
                let res = data[obj.class_name].map(function(item){
                    return dataCreate(item);
                });
                $('.goodslist').html(res);

                //商品数量
                $('.goods_totle').children('span').first().text(data[obj.class_name].length);

                //排序
                let check = true;
                //默认排序
                $('.paixu_sort').on('click','li',function(){
                    if($(this).attr('class') === 'moren'){
                        data[obj.class_name].sort(function(a,b){
                            return b.id - a.id
                        });
                        let res = data[obj.class_name].map(function(item){
                            return dataCreate(item);
                        });
                        $('.goodslist').html(res);
                    }
                });

                //价格排序
                $('.paixu_sort').on('click','li',function(){
                    if($(this).attr('class') === 'jiage'){
                        if(check === true){
                            data[obj.class_name].sort(function(a,b){
                                return a.sale - b.sale
                            });
                            let res = data[obj.class_name].map(function(item){
                                return dataCreate(item);
                            });
                            $('.goodslist').html(res);
                            check = false;
                        }else{
                            data[obj.class_name].sort(function(a,b){
                                return b.sale - a.sale
                            });
                            let res = data[obj.class_name].map(function(item){
                                return dataCreate(item);
                            });
                            $('.goodslist').html(res);
                            check = true;
                        }

                    }
                })

                //页面传参
                $('.goodslist').on('click','li',function(){
                    let id = $(this).attr('data-id');
                    location.href = '../html/goodslis.html?id='+id;
                })
            }
        })
    })(jQuery)

    //封装写入页面
    function dataCreate(item){
        return `<li data-id="${item.id}">
            <div class="img"><img src="${item.images}" /></div>
            <div class="goods_info">
                <div class="price">
                    <span class="sale">${item.sale}</span>
                    <del class="price1">${item.price}</del>
                </div>
                <a href="#" class="goods_info_a">${item.name.replace(/�\?/ig,'')}</a>
            </div>
        </li>`
    }
})
