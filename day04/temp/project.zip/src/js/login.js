//配置参数
require.config({
    //配置别名（虚拟路径）
    paths:{
        //格式：别名--真实路径（基于baseUrl）
        jquery:'../lib/jquery-3.2.1',
        xcarousel:'../lib/jquery-xcarousel/jquery.xCarousel'
    },

    //配置依赖
    shim:{
        xcarousel:['jquery']
    }
})

require(['jquery','xcarousel'],function($){
    //头部脚步内容引入页面
    ;(function($){
        $('#header').load('../html/sign_header.html');
        $('#footer').load('../html/sign_footer.html');
    })(jQuery);

    //验证登录
    ;(function($){
        //生成随机4为验证码
        let randomNum = parseInt(Math.random() * (9999 - 1000 + 1) + 1000)
        $('.yanzhengma').text(randomNum);

        //帐号验证是否存在
        $('#username').on('blur',function(){
            let username = $('#username').val();
            if(!/^[a-z][\w\-]{5,19}$/i.test(username)){
                $('.msg1').html('用户名不合法');
                return false;
            }else{
                $.ajax({
                    url:'../api/login.php',
                    data:{
                        username:username
                    },
                    success:function(data){
                        if(data === 'success'){
                            $('.msg1').html('');
                        }else{
                            $('.msg1').html('此用户不存在');
                            return;
                        }
                    }
                })
            }
        })

        //验证码验证
        //验证码验证
        $('.tel_msg').on('blur',function(){
            //验证码
            let tel_msg = $('.tel_msg').val()*1;console.log(tel_msg,randomNum)
            if(tel_msg !== randomNum){
                $('.msg4').html('验证码不正确');
                return false;
            }else{
                $('.msg4').html('');
            }
        })

        //登录验证
        $('.denglu').on('click',function(){
            let username = $('#username').val();
            let password1 = $('#password1').val();
            let tel_msg = $('.tel_msg').val()*1;
            if(!/^[a-z][\w\-]{5,19}$/i.test(username)){
                $('.msg1').html('用户名不合法');
                return false;
            }
            if(tel_msg !== randomNum){
                $('.msg4').html('验证码不正确');
                return false;
            }else{
                $('.msg4').html('');
            }

            $.ajax({
                url:'../api/login.php',
                data:{
                    username:username,
                    password1:password1,
                    type:'denglu'
                },
                success:function(data){console.log(data)
                    if(data === 'successsuccess'){
                        $('.form').html('登录成功，3秒后自动跳转主页...').css({
                            'color':'#c41f3a',
                            'font-weight':'bold',
                            'font-size':'60px',
                            'padding-top':'20px'
                        });
                        let timer = setTimeout(function(){
                            window.location.href = '../index.html';
                        },3000)
                    }else{
                        $('.msg3').html('密码错误');
                        return;
                    }
                }
            })

        })
    })(jQuery)
})